
## Phase 5 Comparison Results (2026-10-23)

### Commands and artifacts

- `.venv/bin/python papers/QML_financial_benchmark/utils/verify_sweeps.py --validator <plugin>/skills/experiment-logging/scripts/validate_logging.py` → exit 0.
  - 16/16 sweeps COMPLETE.
  - 552 selections recomputed, now including every parameter-matched ANN width and closest-parameter LSTM; all equal the recorded ones.
  - Logging passes (`results/sweep_verification.json`).
- `.venv/bin/python papers/QML_financial_benchmark/utils/compare_fair.py` → exit 0.
  - `results/phase5_comparison.csv`: 181 system rows (131 local, 50 paper-reported).
  - `results/phase5_differences.csv`: quantum − control differences with CIs and p-values.
  - `results/phase5_timing.csv`.
  - Every run is enumerated from `sweep_status.json`, and non-finite metrics are rejected.
- `.venv/bin/python papers/QML_financial_benchmark/utils/plot_phase5_forest.py --output phase5_forest` → `results/phase5_forest.png` (local runs only, scope labels per panel).
- **Focused tests for the fair controls:** `tests/test_baselines.py`, 6 tests. Suite: 51 passed. Ruff clean.

### Commensurability (step 9)

| Pair | Status | Reason |
|---|---|---|
| QNN vs ANN grid, parameter-matched ANN and logistic (T1, every setting) | COMMENSURABLE | Same run, data, folds, optimizer, early stopping, selection rule and seeds; parameter match checked by the verifier |
| QNN vs the same-day diagnostic (KCHOL) | PARTIALLY_COMMENSURABLE | Diagnostic features are not the paper's protocol; used only to explain G1 |
| Local vs paper-reported values (T1) | PARTIALLY_COMMENSURABLE | Different data snapshot; the paper is a single run with unreported QNN parameters |
| QLSTM vs LSTM, matched LSTM, buy-and-hold, flat, logistic (T2) | COMMENSURABLE | Same run, split, loss, stopping, τ grid and fee; scope `partial` (seed-0 selection) |
| Local vs paper-reported Sharpe (T2) | PARTIALLY_COMMENSURABLE | Single-run values inside the random-score null band (G3) |
| QSVR vs SVR family, GARCH, HAR, persistence (T3) | COMMENSURABLE | Same features, refits and Optuna budget; DM on shared dates; single tuning seed |
| Local vs paper-reported QLIKE (T3) | INCOMPARABLE in level, comparable in ranking | Test window unstated (R15) |
| MerLin photonic models vs the qubit models and the same classical controls | COMMENSURABLE as **adaptations** | Same data, protocol and paired ANN grid (T1); same refits and budget (T3) |
| MerLin for T2 and E7 | N/A | Phase 4 exclusions (protocol cannot separate models; amplitude kernel is classical) |

### Wall-clock (`results/phase5_timing.csv`)

- **Hardware:** Apple M4, single-threaded workers. 2–10 concurrent workers depending on the sweep; contention varies between sweeps but not within a run.
- **Measurement:** from run-log timestamps (1 s resolution).
  - T1: per training (candidate × fold).
  - T2: per candidate.
  - T3: per refit, including 50 Optuna trials for SVR-type models.

| Task | Model family | Mean s | Median s | n |
|---|---|---:|---:|---:|
| T1 | ANN | 1.05 | 1 | 3,350 |
| T1 | QNN (qubit statevector) | 21.06 | 11 | 12,120 |
| T1 | photonic QNN (MerLin) | 30.14 | 22 | 800 |
| T2 | LSTM | 14.97 | 10 | 116 |
| T2 | QLSTM | 2,199 | 1,377 | 92 |
| T3 | SVR-linear / RBF / RBF-wide / poly | 8.6 / 16.3 / 25.0 / 37.2 | 7 / 13 / 19 / 28 | 144 each |
| T3 | QSVR angle (10 qubits) | 52.8 | 44.5 | 144 |
| T3 | photonic kernel (MerLin) | 11.5 | 10.5 | 144 |
| T3 | GARCH / HAR / persistence | ≤ 0.2 | 0 | 144 each |

- Quantum models cost 20× (QNN) to 150× (QLSTM) more simulated wall-clock per training than their classical counterparts, with no accuracy gain.
- These are simulator costs, not hardware costs.

### Claim outcomes (step 12)

Tie rule: seed-level 95% CI contains 0 (T1, T2) or DM p ≥ 0.05 (T3).

| Claim | Outcome | Decisive evidence against the strongest fair control |
|---|---|---|
| C1 AAPL | **UNSUPPORTED** | Table V timing: QNN − matched ANN −0.019 [−0.029, −0.010], p = 0.005; QNN − logistic −0.018, p = 0.008. Strict timing: tie (+0.029, p = 0.16). The QNN never exceeds a matched control. |
| C2 KCHOL | **UNSUPPORTED** | Lagged: QNN − matched ANN +0.006 [−0.009, +0.020], p = 0.34 (tie at chance level). Same-day diagnostic: tie with the matched ANN, worse than the ANN grid (p = 0.021). |
| C3 classical wins elsewhere | **PARTIALLY_SUPPORTED** | No setting has the QNN significantly above the matched ANN. The classical side is significantly ahead on TUPRS (−0.047, p = 0.008) and AAPL Table V; the other 10 settings tie. "ANN wins" is supported only as "never loses". The QNN higher-recall pattern is not reproduced (E2). |
| C5 QLSTM Sharpe F1, F2 | **UNSUPPORTED** | QLSTM − matched LSTM Sharpe: F1 −0.19 (p = 0.19), F2 −0.05 (0.84), F3 +0.63 (0.13), F4 −0.00 (0.99), all ties. Buy-and-hold is best or equal-best in F2–F4. Scope `partial`. |
| C6 QLSTM AUC | **UNSUPPORTED** | Against the matched LSTM: F1 −0.001, F2 −0.003, F3 +0.040 (p = 0.055), F4 −0.016 (p = 0.045, matched LSTM better). |
| C7 QSVR on KCHOL; within 0.02–0.04 of RBF | **UNSUPPORTED** (KCHOL part); the "within" part holds | KCHOL: QSVR − RBF +0.018 (p = 0.34), QSVR − completed GARCH +0.022 (p = 0.24), so the QSVR is not lowest. Completed GARCH beats the QSVR significantly on ^GSPC, AAPL and GARAN. |
| C8 QSVR beats linear and poly | **PARTIALLY_SUPPORTED** | Direction 4/4 for both. DM p < 0.05: linear 1/4, poly 3/4. |
| C9 amplitude QSVR competitive | **PARTIALLY_SUPPORTED** | Behind RBF on 3/4 tickers (S5). The kernel is provably classical (Insight 1). d = 64 not run. |
| C10 QSVR ≥ linear SVR | **SUPPORTED** in our runs (single tuning seed) | Both encodings ≥ linear on 4/4 tickers. This contradicts the paper's own Table XIV. |

- **Influences on these outcomes:**
  - Baseline fairness: the paper's baselines were `MISSING_OR_UNFAIR`, and every outcome above is judged against the Phase 1 fair controls.
  - Metric agreement: E2 and AAPL Table V reproduce the paper's AUC levels; Turkish and strict-timing levels do not (G1, G2).
  - Variability: 3–5 seeds per configuration.
  - Execution scope: T2 `partial`; T3 single tuning seed.
  - Unresolved confounders: the exact form of the paper's leak; the T3 test window.
- **MerLin adaptation (not a reproduction):** no photonic model is significantly better than any matched control. Photonic QNN on E2 − matched ANN −0.024, p = 0.0009. On AAPL Table V −0.003, p = 0.19 (tie). The photonic kernel is behind or tied with the qubit QSVR on 4/4 tickers.
- **No quantum or photonic advantage claim is supported** by any fair, commensurable comparison in this reproduction.

### Extensions (step 13)

- None declared in the plan; none run.

'''
