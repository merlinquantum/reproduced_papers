
### Amendment — 2026-10-22T21:35Z (Phase 4 implementation done; before S13–S15)

- **Code added:**
  - `lib/photonic_merlin.py` (`photonic_feature_states`, `PhotonicQNNClassifier`, `spread_input_state`, `reuploading_builder`).
  - Directional `qnn.backend` (`statevector` | `merlin`); `defaults.json` now states `backend: statevector` explicitly, with unchanged behaviour.
  - Volatility model `photonic_kernel`.
- **Configs:** `e6_merlin.json`, `e2_merlin.json`, `e3_table_v_merlin.json`, plus the smoke configs `e2_merlin_reduced.json` and `e6_merlin_reduced.json`.
- **Tests:** `tests/test_photonic_merlin.py`, 9 tests covering:
  - input state;
  - kernel PSD, symmetry and non-triviality;
  - the explicit angle scale and mesh seed reaching the kernel;
  - UNBUNCHED output size C(m, n) and SQ′ mask C(m−1, n−1);
  - gradients through the MZI phases;
  - determinism under seed;
  - config → model.
- Suite: 45 passed. Ruff clean.
- **Smoke runs** (exit 0, logging validated): `outdir/run_20261022-213241` (e2_merlin_reduced) and `outdir/run_20261022-213303` (e6_merlin_reduced). Not results.
- **Corrected compute estimate:** from measured MerLin epoch times (1.0–2.9 s per 75 batches), about 29 CPU-h, not 20.
- **Launch order, at most 4 workers:** S13 (`--max-parallel 2`) and S14 (`--max-parallel 2`) now; S15 (`--max-parallel 2`) when S13 finishes.
- lib+configs fingerprint `FPVAL`.

### Sweep Plan: S13 `e6_merlin` (Phase 4 T3)

- **Varied:** ticker ^GSPC, AAPL, GARAN.IS, KCHOL.IS; seed 0. Expected runs: 4.
- **Config:** `configs/e6_merlin.json`. Tuned per refit by Optuna (50 trials, validation QLIKE): C, ε, n_photons (2, 3), layers (1, 2, 3).
- **Command:**

  ```text
  .venv/bin/python papers/QML_financial_benchmark/utils/sweep.py --name e6_merlin --seeds 0 --max-parallel 2 --variant GSPC configs/e6_merlin.json "--vol-ticker ^GSPC" --variant AAPL configs/e6_merlin.json "--vol-ticker AAPL" --variant GARAN configs/e6_merlin.json "--vol-ticker GARAN.IS" --variant KCHOL configs/e6_merlin.json "--vol-ticker KCHOL.IS"
  ```

- **Analysis:** `utils/stats_volatility.py --base <S5 dir> --extra <S13 dir> --output e6_merlin_vs_qubit`.

### Sweep Plan: S14 `e2_merlin` (Phase 4 T1, E2)

- **Varied:** seed 0–4. Expected runs: 5.
- **Config:** `configs/e2_merlin.json`. Selection and metrics as in S6.
- **Command:**

  ```text
  .venv/bin/python papers/QML_financial_benchmark/utils/sweep.py --config configs/e2_merlin.json --name e2_merlin --seeds 0 1 2 3 4 --max-parallel 2
  ```

### Sweep Plan: S15 `e3_tablev_merlin` (Phase 4 T1, AAPL Table V)

- **Varied:** seed 0–4. Expected runs: 5.
- **Config:** `configs/e3_table_v_merlin.json` with `--ticker AAPL`.
- **Command:**

  ```text
  .venv/bin/python papers/QML_financial_benchmark/utils/sweep.py --config configs/e3_table_v_merlin.json --name e3_tablev_merlin --seeds 0 1 2 3 4 --max-parallel 2 -- --ticker AAPL
  ```

