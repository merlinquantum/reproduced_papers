
## Phase 4 Adaptation Plan — 2026-10-22T20:30Z

**Photonic translation status: `PARTIAL_MERLIN_TRANSLATION`.**

- **User decision** (chat answer): "Kernel + classifier (Recommended)".
- **Code state:** base commit e7beb6a, uncommitted paper folder; lib+configs fingerprint `FPVAL` before Phase 4 code.

### Scope

| Item | T3 photonic kernel (adapts E6) | T1 photonic QNN (adapts E2 and E3 with Table V timing) |
|---|---|---|
| Original scientific role | Fixed quantum feature-space kernel inside SVR for one-day-ahead RV (angle QSVR, Eq. 17) | Parametrized quantum classifier compared with a capacity-matched ANN (QNN families of Fig. 5) |
| Proposed photonic mapping | ψ(x) = Φ(πx)·U_L ⋯ Φ(πx)·U_1 \|s⟩ on m = d modes. U_l are fixed random MZI meshes (`add_entangling_layer(trainable=False, seed)`); Φ is angle encoding with one phase per feature; data is re-uploaded L times. Kernel \|⟨ψ(x)\|ψ(x′)⟩\|² from MerLin amplitude states, then `SVR(kernel="precomputed")` | `QuantumLayer`: trainable mesh, then [angle encoding (θ = π·x, or the hybrid `Linear(d→m)` output), trainable mesh] × L; UNBUNCHED probabilities. Readout SQ′ = P(last mode occupied) as probability; MQ′ = `Linear(outputs→1)`. Families: (non-hybrid, hybrid) × (SQ′, MQ′) |
| Preserved properties | Kernel-SVR role, features (5+5 lags), refit schedule, Optuna budget (50 trials per refit), metric (QLIKE), DM tests | Data, folds, selection protocols, early stopping, optimizer, metrics, paired ANN grid and parameter-matched ANN |
| Changed properties | Qubit map → multi-photon interference map. Hyperparameters are photons n and depth L instead of qubit layers and topology | Qubit RZ-RY-RZ ansatz → MZI meshes. Z readout → photon-occupation readout. Amplitude encoding (AAPL) → hybrid angle encoding (photonic amplitude input of 64 features is not a meaningful analogue) |
| Dataset and task | Same as E6: ^GSPC, AAPL, GARAN, KCHOL, test 2007–2024 | E2 (S&P 500 7-D) and E3 AAPL 64-D Table V; fold-5 test 2020–2021 |
| Evaluation metric | QLIKE (primary), MSE, R², DirAcc; DM against the qubit angle QSVR and SVR-RBF on shared dates (`utils/stats_volatility.py`) | Test AUC (primary), accuracy; seed-level and ensemble tests against the ANN and matched ANN (`utils/stats_directional.py`); comparison with the Phase 3 qubit QNN |
| Photonic assumptions | n ∈ (2, 3) photons, m = 10 modes, input state spread over the modes, FOCK amplitudes for the exact overlap. On hardware the fidelity is the probability of the collision-free input pattern after U(x′)†U(x), detectable with threshold detectors. Noiseless | n ∈ (2, 3) photons, m = 7 (E2, non-hybrid needs m = d) or m ∈ (6, 8) (AAPL, hybrid only). UNBUNCHED, threshold detection, analytic probabilities, noiseless |
| Expected limitations | Single Optuna seed (as in Phase 3); no shot noise; kernel exactness on hardware not tested | Smaller grid than the qubit QNN (16 vs 24 or 72 candidates); exact gradients by autograd (no sampling) |
| Evaluation scope | Full E6 protocol on all 4 tickers; single tuning seed (`preliminary` for tuner variance) | `paper-accurate` protocol for E2 and AAPL Table V, 5 seeds. Other T1 settings omitted (no signal for any model) |

### In-scope MerLin configurations, seeds and run counts

- `configs/e6_merlin.json`: model `photonic_kernel`. Optuna space: C, ε (Table VIII), photons (2, 3), re-uploads L (1, 2, 3). Seed 0. Tickers ^GSPC, AAPL, GARAN.IS, KCHOL.IS. **4 runs.**
- `configs/e2_merlin.json`: photonic QNN with 4 families × n (2, 3) × L (1, 2) on m = 7 (16 candidates), plus the Phase 3 ANN grid. Seeds 0–4. **5 runs.**
- `configs/e3_table_v_merlin.json`: hybrid families only (2) × m (6, 8) × n (2, 3) × L (1, 2) (16 candidates), plus the ANN grid. AAPL. Seeds 0–4. **5 runs.**
- **Expected run count:** 14. At most 4 parallel workers.

### Comparison with Phase 3 (predeclared)

- **T3:**
  - The photonic kernel "preserves the qubit QSVR behaviour" on a ticker if its QLIKE is within ±0.02 of the qubit angle QSVR's (the paper's own closeness scale is 0.02–0.04) and its position relative to SVR-RBF and SVR-linear is the same (better or worse).
  - Reported per ticker with DM p-values against `qsvr_angle` and `svr_rbf`.
- **T1:**
  - The photonic QNN "preserves" the qubit QNN behaviour if its 5-seed mean test AUC (leak_free) is within ±0.02 of the Phase 3 qubit QNN mean, and the sign of (QNN − ANN) matches.
  - Phase 3 qubit QNN means: E2 0.7574 (QNN − ANN +0.0005); AAPL Table V 0.6220 (QNN − ANN −0.0186).
- No photonic advantage is claimed unless it beats the ANN and the parameter-matched ANN at the seed level (p < 0.05) and in the seed ensemble.

### Excluded scope

- **T2 QLSTM:** the protocol cannot separate models (G3). A photonic QLSTM cannot change a verdict, and it would be the most expensive run.
- **E7 amplitude QSVR:** no meaningful mapping; a fixed unitary cancels in the fidelity on any platform.
- **T1 on the Turkish 3-D and strictly lagged 64-D settings:** no model has signal.
- **E6/E7 additional Optuna seeds:** not run, same as Phase 3.

### MerLin API findings (to the MerLin team feedback)

1. `CircuitBuilder.add_angle_encoding(scale=...)` is recorded in `angle_encoding_specs`, but `QuantumLayer` applies the raw input as the phase. Known-answer test with 1 photon, 4 modes: measured overlap 0.176422 equals the θ = x prediction, not θ = πx (0.806637). Scale is applied explicitly in our code.
2. `FidelityKernel(FeatureMap(builder=...))` with a fixed `add_entangling_layer(trainable=False)` followed by `add_angle_encoding` returned a kernel of all ones on 6 random points. The amplitude-state construction gives non-trivial values. Not investigated further; our implementation does not use `FidelityKernel`.

